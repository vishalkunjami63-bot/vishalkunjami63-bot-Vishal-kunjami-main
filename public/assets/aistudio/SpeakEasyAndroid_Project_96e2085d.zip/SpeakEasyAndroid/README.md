# SpeakEasy Android project

This project wraps the supplied SpeakEasy HTML app in an Android WebView.

## Build an APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `SpeakEasyAndroid` folder.
4. Wait for Gradle sync. Install Android SDK Platform 35 if Android Studio asks.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Notes
- The app uses the supplied HTML and keeps progress in the WebView's local storage.
- Internet is needed for the HTML's online fonts, icons, and CDN libraries.
- Speaking practice depends on Android WebView and device speech-recognition support; microphone permission is requested when needed.
- This ZIP is an Android Studio project, **not a compiled APK**. This environment does not have the Android SDK/Gradle build tools needed to compile and sign an APK.
